# Kiln

แชทหน้าเดียวที่รันบน GitHub Pages — กุญแจ API เก็บในเบราว์เซอร์ของคุณเท่านั้น

```
index.html      โครงหน้า
css/styles.css  สไตล์ทั้งหมด
js/app.js       ตรรกะทั้งหมด (provider, สตรีม, ไฟล์, ตั้งค่า)
proxy/          Cloudflare Worker สำหรับแก้ CORS (ไม่บังคับ)
```

## Deploy หน้าเว็บ
อัปโหลด `index.html`, `css/`, `js/` ขึ้น repo แล้วเปิด Settings → Pages → Deploy from branch

## เมื่อเจอ "Load failed" / "Failed to fetch"
1. เปิดหน้าตั้งค่า → กด **ทดสอบกุญแจนี้** จะเห็นสาเหตุที่ละเอียดกว่าเดิม
2. ถ้าปลายทางไม่เปิด CORS (เช่น DeepSeek หรือค่าย custom) ให้ deploy พร็อกซี:
   ```bash
   cd proxy
   # แก้ ALLOWED_ORIGINS ใน wrangler.toml ให้เป็นโดเมน github.io ของคุณ
   npx wrangler deploy
   ```
3. คัดลอก URL ที่ได้ (`https://kiln-proxy.<ชื่อ>.workers.dev`) ไปใส่ในหน้าตั้งค่า → **พร็อกซี (แก้ CORS)** → กด **ทดสอบพร็อกซี**

แอปจะยิงตรงก่อนเสมอ และถอยมาใช้พร็อกซีเองเมื่อยิงตรงไม่ผ่าน

> พร็อกซีเห็นกุญแจใน header ของคำขอ จึงควร deploy ของตัวเอง และล็อก `ALLOWED_ORIGINS` ให้เป็นโดเมนของคุณเท่านั้น
