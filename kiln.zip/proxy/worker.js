/**
 * Kiln CORS proxy — Cloudflare Worker
 *
 * เรียกใช้: GET/POST https://<worker>/?url=<ปลายทางที่ encodeURIComponent แล้ว>
 * - ส่งต่อ method / header / body ไปยังปลายทางตามเดิม และสตรีมคำตอบกลับ (SSE ใช้ได้)
 * - เติมหัว CORS ให้เบราว์เซอร์
 * - ไม่เก็บ/ไม่ log กุญแจ — กุญแจผ่านแค่ใน header ของคำขอนั้น
 *
 * ความปลอดภัย: รับเฉพาะ Origin ที่อยู่ใน ALLOWED_ORIGINS และโฮสต์ปลายทางที่อยู่ในรายการอนุญาต
 * ตั้งค่าใน wrangler.toml ([vars]) ไม่ต้องแก้โค้ดนี้
 */
const DEFAULT_HOSTS = [
  'generativelanguage.googleapis.com', // Gemini
  'api.openai.com',
  'api.anthropic.com',
  'api.deepseek.com',
  'openrouter.ai',
  'api.tavily.com',
  's.jina.ai',
  'r.jina.ai',
  'api.duckduckgo.com',
];

const list = (s) => String(s || '').split(',').map((x) => x.trim()).filter(Boolean);

// หัวที่ไม่ควรส่งต่อไปยังปลายทาง
const DROP = /^(host|origin|referer|cookie|content-length|connection|accept-encoding|cf-.*|x-forwarded-.*|x-real-ip|sec-.*)$/i;

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowedOrigins = list(env.ALLOWED_ORIGINS);
    const originOk = allowedOrigins.includes(origin);

    const cors = {
      'Access-Control-Allow-Origin': originOk ? origin : 'null',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': request.headers.get('Access-Control-Request-Headers') || '*',
      'Access-Control-Expose-Headers': '*',
      'Access-Control-Max-Age': '86400',
      Vary: 'Origin',
    };
    const json = (obj, status = 200) =>
      new Response(JSON.stringify(obj), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (!originOk) return json({ error: 'origin not allowed' }, 403);

    const reqUrl = new URL(request.url);
    if (reqUrl.pathname === '/health') return json({ ok: true });

    const target = reqUrl.searchParams.get('url');
    if (!target) return json({ error: 'missing ?url=' }, 400);

    let dest;
    try { dest = new URL(target); } catch { return json({ error: 'bad url' }, 400); }
    if (dest.protocol !== 'https:') return json({ error: 'https only' }, 400);

    const hosts = [...DEFAULT_HOSTS, ...list(env.EXTRA_HOSTS)];
    if (!hosts.includes(dest.hostname)) return json({ error: 'host not allowed: ' + dest.hostname }, 403);

    const headers = new Headers();
    for (const [k, v] of request.headers) if (!DROP.test(k)) headers.set(k, v);

    let upstream;
    try {
      upstream = await fetch(dest.toString(), {
        method: request.method,
        headers,
        body: request.method === 'GET' || request.method === 'HEAD' ? undefined : request.body,
        redirect: 'follow',
      });
    } catch (e) {
      return json({ error: 'upstream fetch failed', detail: String(e && e.message || e) }, 502);
    }

    const out = new Headers(upstream.headers);
    out.delete('content-encoding');
    out.delete('content-length');
    for (const [k, v] of Object.entries(cors)) out.set(k, v);
    return new Response(upstream.body, { status: upstream.status, statusText: upstream.statusText, headers: out });
  },
};
